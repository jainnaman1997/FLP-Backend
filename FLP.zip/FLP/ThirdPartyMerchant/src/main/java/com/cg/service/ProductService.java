package com.cg.service;

import java.util.List;

import com.cg.bean.Product;

public interface ProductService {

	public List<Product> getAll();
	public String addProduct(Product p);
	public String update(int id, Product p);
	public String delete(int productId);
}
