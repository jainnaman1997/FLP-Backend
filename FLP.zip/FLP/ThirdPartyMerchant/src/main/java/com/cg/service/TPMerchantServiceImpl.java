package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Merchant;
import com.cg.dao.TPMerchantDao;
import com.cg.exception.Exception;

@Service
@Transactional
public class TPMerchantServiceImpl implements TPMerchantService {

	@Autowired
	TPMerchantDao dao;
	
	@Transactional(readOnly=true)
	@Override
	public List<Merchant> getAll() {
		// TODO Auto-generated method stub
		if(dao.findAll().isEmpty()) {
			throw new Exception("No Third Party Merchant Exist");
		}
		return dao.findTPMerchant("Disapproved");
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public String update(int id, Merchant t) {
		Merchant m;
		Optional<Merchant> p = dao.findById(id);
		if (p.isPresent())
			m = p.get();
		else
			throw new Exception("Merchant doesn't exist"); // throwing custom exception if account doesn't exist
		
//		dao.delete(a);
//		dao.save(account);
		
		m.setFirstName(t.getFirstName());
		m.setLastName(t.getLastName());
		m.setCompany(t.getCompany());
		m.setEmailid(t.getEmailid());
		m.setMobileno(t.getMobileno());
		m.setStatus(t.getStatus());
		return "Third Party Merchant updated";
	}

	/*@Transactional
	@Override
	public String delete(int merchantId) {
		// TODO Auto-generated method stub
		dao.deleteById(merchantId);
		return "Third Party Merchant deleted";
	}*/

	@Transactional
	@Override
	public String addAccount(Merchant t) {
		// TODO Auto-generated method stub
			dao.save(t);
			return "Third Party Merchant added";
	}

}
