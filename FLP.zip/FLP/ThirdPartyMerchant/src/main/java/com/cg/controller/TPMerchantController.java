package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Merchant;
import com.cg.bean.Product;
import com.cg.service.ProductService;
import com.cg.service.TPMerchantService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/ThirdPartyMerchant")
public class TPMerchantController {

	@Autowired
	TPMerchantService tpmService;
	
	@Autowired
	ProductService pService;
	
	
	//----------------TPMerchant-----------------------------
	
	
	
	@PostMapping(value="/addTPMerchant", consumes= {"application/json"})
	public String addTPMerchant(@RequestBody Merchant t) {
		return tpmService.addAccount(t);
	}
	
	/*@DeleteMapping(value="/deleteTPMerchant/{mid}")
	public String deleteTPMerchant(@PathVariable int mid) {
		tpmService.delete(mid);
		return "Third Party Merchant deleted";
	}*/
	
	@PutMapping(value="/updateTPMerchant/{id}", consumes= {"application/json"})
	public String updateTPMerchant(@RequestBody Merchant t, @PathVariable int id) {
		tpmService.update(id, t);
		return "Third Party Merchant updated";
	}
	
	@GetMapping(value="/tpMerchant", produces= {"application/json"})
	public List<Merchant> getAllTPMerchant(){
		return tpmService.getAll();
	}	
	
	
	
	//----------------TPMerchant-----------------------------
	
	
	//----------------Product--------------------------------
	
	
	
	@PostMapping(value="/addProduct", consumes= {"application/json"})
	public String add(@RequestBody Product p) {
		return pService.addProduct(p);
	}
	
	/*@DeleteMapping(value="/deleteProduct/{pid}")
	public String deleteProduct(@PathVariable int pid) {
		pService.delete(pid);
		return "Product deleted";
	}*/
	
	@PutMapping(value="/updateProduct/{id}", consumes= {"application/json"})
	public String updateProduct(@RequestBody Product p, @PathVariable int id) {
		pService.update(id, p);
		return "Product updated";
	}
	
	@GetMapping(value="/product", produces= {"application/json"})
	public List<Product> getAllProduct(){
		return pService.getAll();
	}
	
	
	
	//----------------Product---------------------------------
}
