package com.cg.service;

import java.util.List;

import com.cg.bean.Merchant;

public interface TPMerchantService {

	public List<Merchant> getAll();
	public String addAccount(Merchant t);
	public String update(int id,Merchant t);
	public String delete(int merchantId);
	
}
