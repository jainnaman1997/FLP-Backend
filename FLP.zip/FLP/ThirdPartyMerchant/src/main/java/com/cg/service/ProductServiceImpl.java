package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.exception.Exception;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao dao;
	
	@Transactional(readOnly=true)
	@Override
	public List<Product> getAll() {
		// TODO Auto-generated method stub
		if(dao.findAll().isEmpty()) {
			throw new Exception("No Product Exists");
		}
		return dao.findAll();
	}

	@Transactional
	@Override
	public String addProduct(Product p) {
		// TODO Auto-generated method stub
			dao.save(p);
			return "Product added";
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public String update(int id, Product t) {
		Product m;
		Optional<Product> p = dao.findById(id);
		if (p.isPresent())
			m = p.get();
		else
			throw new Exception("Product doesn't exist"); // throwing custom exception if account doesn't exist
		
		m.setProductName(t.getProductName());
		m.setTag(t.getTag());
		m.setCompany(t.getCompany());
		m.setPhoto(t.getPhoto());
		m.setDescription(t.getDescription());
		m.setQuantity(t.getQuantity());
		m.setCategory(t.getCategory());
		m.setSubcategory(t.getSubcategory());
		m.setSoldQuantities(t.getSoldQuantities());
		m.setPrice(t.getPrice());
		m.setReleaseDate(t.getReleaseDate());
		
		return "Third Party Merchant updated";
	}

	/*@Transactional
	@Override
	public String delete(int productId) {
		// TODO Auto-generated method stub
		dao.deleteById(productId);
		return "Product deleted";
	}*/

}
