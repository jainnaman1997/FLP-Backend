﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { ManageTPMerchant } from './tpMerchant';
import { AddProduct } from './add-product';
import { DeleteProduct } from './product';
import { TPMerchantService } from './tpMerchant.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [
        BrowserModule, HttpClientModule, FormsModule
        
    ],
    declarations: [
        AppComponent, ManageTPMerchant, AddProduct, DeleteProduct
		],
    providers: [ TPMerchantService ],
    bootstrap: [AppComponent]
})

export class AppModule { } 