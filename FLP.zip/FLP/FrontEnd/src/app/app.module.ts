﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { ManageTPMerchant } from './tpMerchant';
import { TPMerchantService } from './tpMerchant.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [
        BrowserModule, HttpClientModule, FormsModule
        
    ],
    declarations: [
        AppComponent, ManageTPMerchant
		],
    providers: [ TPMerchantService ],
    bootstrap: [AppComponent]
})

export class AppModule { } 