import { Component } from "@angular/core";

@Component({
    selector: 'delete-product',
    templateUrl: './product.html'
})

export class DeleteProduct{

}