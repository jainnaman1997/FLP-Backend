import { Injectable } from "@angular/core";
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { Product } from './Product.model';
import { TPMerchant } from './tpMerchant.model';

const httpOptions={
    headers: new HttpHeaders({ 'Content-Type' : 'application/json'})
};

@Injectable()
export class TPMerchantService{

    constructor(private http:HttpClient){}

    private tpUrl='http://localhost:5000/ThirdPartyMerchant';

    public getTPMerchant(){
        return this.http.get<TPMerchant[]>(this.tpUrl + "/tpMerchant");
    }

    public deleteTPMerchant(tpmerchant){
        return this.http.delete(this.tpUrl + "/deleteTPMerchant/" + tpmerchant.merchantId);
    }

    public updateTPMerchant(tpmerchant){
        return this.http.put(this.tpUrl + "/updateTPMerchant/" + tpmerchant.merchantId, tpmerchant);
    }

    public addProduct(product){
        return this.http.post<Product>(this.tpUrl + "/addProduct/", product);
    }

    public deleteProduct(product){
        return this.http.delete(this.tpUrl + "/deleteProduct/" + product.productid);
    }

    public updateProduct(product){
        return this.http.put(this.tpUrl + "/updateProduct/" + product.productid, product);
    }

    public getProduct(){
        return this.http.get<Product[]>(this.tpUrl + "/product/");
    }
    
}