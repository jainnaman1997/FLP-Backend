import { Component, OnInit } from "@angular/core";
import { TPMerchant } from './tpMerchant.model';
import { TPMerchantService } from './tpMerchant.service';
import { Product } from './product.model';

@Component({
    selector: 'tpm',
    templateUrl: './tpMerchant.html'
})

export class ManageTPMerchant implements OnInit{

    tpmerchants: TPMerchant[];
    tpmerchant: TPMerchant = new TPMerchant();
    id:string="";
    status=false;
    constructor(private tpmerchantservice: TPMerchantService){}

    ngOnInit(){
        this.tpmerchantservice.getTPMerchant()
        .subscribe(data => {
            this.tpmerchants = data;
        });

        this.tpmerchantservice.getProduct()
        .subscribe(data => {
            this.products = data;
        });
    }

    deleteTPMerchant(tpmerchant: TPMerchant): void {
        this.tpmerchantservice.deleteTPMerchant(tpmerchant).subscribe(data => {
            this.tpmerchants = this.tpmerchants.filter(u => u !==tpmerchant);
        });
    };

    editTPMerchant(data: TPMerchant):void{
        this.status=true;
        this.tpmerchant.company=data.company;
        this.tpmerchant.firstName=data.firstName;
        this.tpmerchant.lastName=data.lastName;
        this.tpmerchant.emailid=data.emailid;
        this.tpmerchant.mobileno=data.mobileno;
        this.tpmerchant.status=data.status;
        this.tpmerchant.merchantId=data.merchantId;
    }

    updateTPMerchant(){
        this.tpmerchantservice.updateTPMerchant(this.tpmerchant).subscribe(data => { console.log("updated")});
    }



    products: Product[];
    product: Product = new Product();


}